package com.example.sydemo.model;

import android.content.ClipData;

import androidx.annotation.NonNull;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class basemodel<Item> {
     Item[] a=((Item[]) (new Object[10]));
}
