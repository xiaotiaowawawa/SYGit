package com.example.sydemo.ui;

import android.content.Context;
import android.view.View;

public interface ActivityDao {
    public View getMainView();
    public Context getContext();
}
