package com.example.sydemo.ui;

import android.view.View;

public interface ButtonOnclick {
    public void onclick(View v);
}
