package com.example.sydemo.ui.toolbar;

import android.view.View;

import com.example.sydemo.ui.ActivityDao;

public interface ToolbarDao extends ActivityDao {
public View getToolbarParentView();
}
