package com.example.sydemo.util;

import androidx.core.content.FileProvider;

public class MyFileProvider extends FileProvider {
}
