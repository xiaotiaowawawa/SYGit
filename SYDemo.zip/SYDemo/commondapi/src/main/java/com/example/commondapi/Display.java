package com.example.commondapi;

public interface Display {
    String display();
}
